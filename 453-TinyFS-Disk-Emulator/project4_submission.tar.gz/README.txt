Names: Frank Assumma, Savannah Bosley, Sophie Russ

Our code is working alright, but has some problems with updating certain values.